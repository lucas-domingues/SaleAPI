﻿namespace Sales.API.Models.Entities
{
    public class Rating
    {
        public int Id { get; set; }
        public double Rate { get; set; }
        public int Count { get; set; }
    }
}
