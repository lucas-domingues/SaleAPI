﻿namespace Sales.API.Models.Entities
{
    public class Name
    {
        public int Id { get; set; }
        public string Firstname { get; set; }
        public string Lastname { get; set; }
    }
}