﻿namespace Sales.API.Models.Enum
{
    public enum Role
    {
        Customer,
        Manager,
        Admin
    }
}
