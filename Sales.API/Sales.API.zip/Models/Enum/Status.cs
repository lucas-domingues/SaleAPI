﻿namespace Sales.API.Models.Enum
{
    public enum Status
    {
        Active,
        Inactive,
        Suspended
    }

}
