﻿namespace Sales.API.Models.Entities
{
    public class Geolocation
    {
        public int Id { get; set; }
        public string Lat { get; set; }
        public string Long { get; set; }
    }
}